<?php
require_once 'dbconn.php'; // Includes the database connection file

// Fetch all records
if (isset($_POST['fetch'])) {
    $query = "SELECT * FROM health_declarations";
    $result = $conn->query($query);
    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    echo json_encode($data);
    exit();
}

// Add a new record
if (isset($_POST['add'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile_number = $_POST['mobile_number'];
    $age = $_POST['age'];
    $body_temperature = $_POST['body_temperature'];
    $covid_diagnosed = $_POST['covid_diagnosed'];
    $covid_vaccinated = $_POST['covid_vaccinated'];
    $nationality = $_POST['nationality'];
    $gender = $_POST['gender'];

    $query = "INSERT INTO health_declarations (fname, lname, mobile_number, age, body_temperature, covid_diagnosed, covid_vaccinated, nationality, gender) 
              VALUES ('$fname', '$lname', '$mobile_number', $age, '$body_temperature', '$covid_diagnosed', '$covid_vaccinated', '$nationality', '$gender')";
    if ($conn->query($query)) {
        echo "Record added successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
    exit();
}

// Update a record
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $update_data = $_POST['update_data'];

    foreach ($update_data as $update) {
        $column = $update['column'];
        $new_value = $conn->real_escape_string($update['new_value']);

        $query = "UPDATE health_declarations SET $column = '$new_value' WHERE id = $id";
        $conn->query($query);
    }

    echo "Record updated successfully.";
    exit();
}

// Delete a record
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query = "DELETE FROM health_declarations WHERE id = $id";

    if ($conn->query($query)) {
        echo "Record deleted successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
    exit();
}
?>
