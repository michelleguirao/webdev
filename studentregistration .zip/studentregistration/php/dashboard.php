<?php
session_start();
require_once 'dbconn.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Content-Type: application/json');
    echo json_encode(['isSuccess' => false, 'msg' => 'User not logged in']);
    exit();
}

$username = $_SESSION['username'];

try {
    // Prepare SQL query to fetch health declarations
    $query = "SELECT * FROM health_declarations WHERE username = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        throw new Exception("Failed to prepare statement.");
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user data exists
    $userData = $result->num_rows > 0 ? $result->fetch_assoc() : null;

    // Close statement and database connection
    $stmt->close();
    $conn->close();

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'isSuccess' => true,
        'username' => $username,
        'userData' => $userData
    ]);
} catch (Exception $e) {
    // Handle any errors
    header('Content-Type: application/json');
    echo json_encode(['isSuccess' => false, 'msg' => $e->getMessage()]);
}
?>
