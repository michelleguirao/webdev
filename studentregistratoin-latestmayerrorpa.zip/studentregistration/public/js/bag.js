(function () {
  let currentFilter = "all";
  let currentUser = ""; // To store the current user

  // Fetch the current user from getcurrentuser.php
  async function fetchCurrentUser() {
    try {
      const response = await fetch("php/getcurrentuser.php");
      const data = await response.json();

      if (data.username) {
        currentUser = data.username; // Set currentUser to the logged-in user's username
        fetchBooksbyStatus(); // Fetch books once the user is set
      } else {
        console.error("User not logged in");
      }
    } catch (error) {
      console.error("Error fetching current user:", error);
    }
  }

  // Function to fetch and display books based on the current filter and user
  async function fetchBooksbyStatus() {
    try {
      if (!currentUser) return; // Don't fetch books if the current user is not set

      const response = await fetch(
        `php/bag.php?status=${currentFilter}&user=${currentUser}`
      );
      const books = await response.json();
      const tableBody = document.querySelector("#bookTable tbody");

      tableBody.innerHTML =
        books.length === 0
          ? "<tr><td colspan='2'>No books found for this filter</td></tr>"
          : books
              .map(
                (book) => `
            <tr>
              <td>${book.bname}</td>
              <td class="status-cell">${book.status}</td>
            </tr>
          `
              )
              .join("");
    } catch (error) {
      console.error("Error fetching books:", error);
    }
  }

  // Event listeners for filter buttons
  document.querySelectorAll(".filter-btn").forEach((button) => {
    button.addEventListener("click", () => {
      currentFilter = button.dataset.filter || "all";
      fetchBooksbyStatus();
    });
  });

  // Initialize the user and table with all books
  fetchCurrentUser();
})();
