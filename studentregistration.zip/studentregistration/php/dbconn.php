<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

class Config {
    public $conn; // Define the property

    public function __construct() {
        $dbservername = 'localhost';
        $username = 'root';
        $password = '';
        $dbname = 'health_database';
        $port = 3306;
        
        // Initialize connection with the specified port
        $this->conn = new mysqli($dbservername, $username, $password, $dbname, $port);
        
        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
}
$config = new Config();
$conn = $config->conn;
?>

