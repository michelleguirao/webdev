<?php
ini_set('display_errors', 1);
session_start();
require 'dbconn.php';

class LoginStudent {

    public function checkUser($username) {
        error_reporting(E_ERROR);
        $config = new Config();
        $response = array();
        $conn = $config->conn;

        if ($conn->connect_error) {
            return $conn->connect_error;
        } else {
            // Modify query to include is_admin
            $query = 'SELECT username, is_admin from users where username = ?';

            if ($stmt = $conn->prepare($query)) {
                $stmt->bind_param('s', $username);

                if ($stmt->execute()) {
                    $stmt->bind_result($username, $is_admin);
                    $stmt->store_result();

                    if ($stmt->num_rows > 0) {
                        // Return both status and is_admin
                        $stmt->fetch();
                        return ['status' => 'USER_FOUND', 'is_admin' => (bool)$is_admin];
                    } else {
                        return 'USER_NOT_FOUND';
                    }
                    $stmt->close();
                } else {
                    return $stmt->error;
                }
            } else {
                return $conn->error;
            }
            $conn->close();
        }
    }

    public function getHashPassword($username) {
        error_reporting(E_ERROR);
        $config = new Config();
        $response = array();
        $conn = $config->conn;

        if ($conn->connect_error) {
            return $conn->connect_error;
        } else {
            $query = 'SELECT password from users where username = ?';

            if ($stmt = $conn->prepare($query)) {
                $stmt->bind_param('s', $username);

                if ($stmt->execute()) {
                    $stmt->bind_result($password);
                    $stmt->store_result();

                    if ($stmt->num_rows > 0) {
                        while ($stmt->fetch()) {
                            return $password;
                        }
                    }
                    $stmt->close();
                } else {
                    return $stmt->error;
                }
            } else {
                return $conn->error;
            }
            $conn->close();
        }
    }

    // Simplify password verification (no need to compare the result to the password)
    public function verifyInput($password, $hashpassword) {
        return password_verify($password, $hashpassword);
    }

    public function doLogin($username, $password) {
        $app = new LoginStudent();
        $response = array();

        $checkUser = $app->checkUser($username);

        if (is_array($checkUser) && $checkUser['status'] == 'USER_FOUND') {
            $hashpassword = $app->getHashPassword($username);
            $verifyPassword = $app->verifyInput($password, $hashpassword);

            if ($verifyPassword) { // If password matches
                $_SESSION['is_admin'] = $checkUser['is_admin'];
                $_SESSION['username'] = $username;

                $response['isSuccess'] = true;
                $response['value'] = 1;
                $response['msg'] = 'Login Successful';
                $response['isAdmin'] = $_SESSION['is_admin'];
            } else {
                $response['isSuccess'] = false;
                $response['value'] = 0;
                $response['msg'] = 'Invalid Login Credentials';
            }
        } else if ($checkUser == 'USER_NOT_FOUND') {
            $response['isSuccess'] = false;
            $response['value'] = 0;
            $response['msg'] = 'User not found';
        } else {
            $response['isSuccess'] = false;
            $response['value'] = 0;
            $response['msg'] = $checkUser;
        }
        return json_encode($response);
    }
}

$app = new LoginStudent();

if (isset($_REQUEST['action'])) {
    if ($_REQUEST['action'] == 'isLogin') {
        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];

        $response = $app->doLogin($username, $password);

        echo $response;
        $decode_response = json_decode($response);

        if ($decode_response->isSuccess) {
            $_SESSION['username'] = $username;
        }
    }
} else {
    echo 'ERROR: No direct access';
}
?>
