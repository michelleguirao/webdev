<?php
session_start();

// Ensure the database connection is included only once
require_once 'dbconn.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$username = $_SESSION['username']; // Get the username from session

// Query to fetch the health declaration data based on the logged-in username
$query = "SELECT * FROM health_declarations WHERE username = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if data is found
    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc(); // Fetch data as associative array
    } else {
        $userData = null;
    }
    $stmt->close();
} else {
    echo "Failed to prepare statement: " . $conn->error;
    exit();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>

    <?php if ($userData): ?>
        <h2>Health Declaration:</h2>
        <p><strong>First Name:</strong> <?php echo htmlspecialchars($userData['fname']); ?></p>
        <p><strong>Last Name:</strong> <?php echo htmlspecialchars($userData['lname']); ?></p>
        <p><strong>Mobile Number:</strong> <?php echo htmlspecialchars($userData['mobile_number']); ?></p>
        <p><strong>Age:</strong> <?php echo htmlspecialchars($userData['age']); ?></p>
        <p><strong>Body Temperature:</strong> <?php echo htmlspecialchars($userData['body_temperature']); ?></p>
        <p><strong>Covid Diagnosed:</strong> <?php echo htmlspecialchars($userData['covid_diagnosed']); ?></p>
        <p><strong>Covid Vaccinated:</strong> <?php echo htmlspecialchars($userData['covid_vaccinated']); ?></p>
        <p><strong>Nationality:</strong> <?php echo htmlspecialchars($userData['nationality']); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($userData['gender']); ?></p>
    <?php else: ?>
        <p>No health declaration found for this user.</p>
    <?php endif; ?>

    <button id="logoutBtn">Log Out</button>

    <script src="../public/plugins/jquery/jquery-3.7.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // Log out when the button is clicked
            $("#logoutBtn").click(function() {
                window.location.href = "logout.php";
            });
        });
    </script>
</body>
</html>
