<?php
// Include the database connection file
include('dbconn.php');

// Create a new instance of the Config class to establish the connection
$config = new Config();
$conn = $config->conn;

// Add New Record to the database
if (isset($_POST['add'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile_number = $_POST['mobile_number'];
    $age = $_POST['age'];
    $body_temperature = $_POST['body_temperature'];
    $covid_diagnosed = $_POST['covid_diagnosed'];
    $covid_vaccinated = $_POST['covid_vaccinated'];
    $nationality = $_POST['nationality'];
    $gender = $_POST['gender'];

    $sql = "INSERT INTO health_declarations (fname, lname, mobile_number, age, body_temperature, covid_diagnosed, covid_vaccinated, nationality, gender)
            VALUES ('$fname', '$lname', '$mobile_number', '$age', '$body_temperature', '$covid_diagnosed', '$covid_vaccinated', '$nationality', '$gender')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Edit Record (Get data for editing)
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    $sql = "SELECT * FROM health_declarations WHERE id = $edit_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}

// Update Record after editing
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile_number = $_POST['mobile_number'];
    $age = $_POST['age'];
    $body_temperature = $_POST['body_temperature'];
    $covid_diagnosed = $_POST['covid_diagnosed'];
    $covid_vaccinated = $_POST['covid_vaccinated'];
    $nationality = $_POST['nationality'];
    $gender = $_POST['gender'];

    $sql = "UPDATE health_declarations SET fname='$fname', lname='$lname', mobile_number='$mobile_number', age='$age', 
            body_temperature='$body_temperature', covid_diagnosed='$covid_diagnosed', covid_vaccinated='$covid_vaccinated', 
            nationality='$nationality', gender='$gender' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete Record
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM health_declarations WHERE id = $delete_id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch all records for displaying in the table
$sql = "SELECT * FROM health_declarations";
$result = $conn->query($sql);

// Close connection (optional)
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Users Database</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-4">
                    <div class="card-header">
                        <h2 class="display-6 text-center">Health Declarations</h2>
                    </div>
                    <div class="card-body">
                        <!-- Table to display health_declarations data -->
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Mobile Number</th>
                                    <th>Age</th>
                                    <th>Body Temperature</th>
                                    <th>Covid Diagnosed</th>
                                    <th>Covid Vaccinated</th>
                                    <th>Nationality</th>
                                    <th>Gender</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- PHP code to dynamically fill in the rows -->
                                <?php
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row["id"] . "</td>";
                                        echo "<td>" . $row["fname"] . "</td>";
                                        echo "<td>" . $row["lname"] . "</td>";
                                        echo "<td>" . $row["mobile_number"] . "</td>";
                                        echo "<td>" . $row["age"] . "</td>";
                                        echo "<td>" . $row["body_temperature"] . "</td>";
                                        echo "<td>" . $row["covid_diagnosed"] . "</td>";
                                        echo "<td>" . $row["covid_vaccinated"] . "</td>";
                                        echo "<td>" . $row["nationality"] . "</td>";
                                        echo "<td>" . $row["gender"] . "</td>";
                                        echo "<td>
                                            <a href='?edit_id=" . $row["id"] . "' class='btn btn-primary btn-sm'>Edit</a>
                                            <a href='?delete_id=" . $row["id"] . "' class='btn btn-danger btn-sm'>Delete</a>
                                        </td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='11' class='text-center'>No records found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add New Record Form -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>Add New Record</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Last Name</label>
                            <input type="text" name="lname" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Mobile Number</label>
                            <input type="text" name="mobile_number" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Age</label>
                            <input type="number" name="age" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Body Temperature</label>
                            <input type="text" name="body_temperature" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Covid Diagnosed</label>
                            <select name="covid_diagnosed" class="form-control" required>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Covid Vaccinated</label>
                            <select name="covid_vaccinated" class="form-control" required>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Nationality</label>
                            <input type="text" name="nationality" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Gender</label>
                            <select name="gender" class="form-control" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" name="add" class="btn btn-success mt-3">Add Record</button>
                </form>
            </div>
            <div class="text-end mt-3">
            <button id="logoutBtn" class="btn btn-danger">Log Out</button>
        </div>
        </div>

        <?php if (isset($row)) { ?>
            <!-- Edit Form -->
            <div class="card mt-4">
                <div class="card-header">
                    <h3>Edit Record</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <label>First Name</label>
                                <input type="text" name="fname" class="form-control" value="<?php echo $row['fname']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Last Name</label>
                                <input type="text" name="lname" class="form-control" value="<?php echo $row['lname']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Mobile Number</label>
                                <input type="text" name="mobile_number" class="form-control" value="<?php echo $row['mobile_number']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Age</label>
                                <input type="number" name="age" class="form-control" value="<?php echo $row['age']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Body Temperature</label>
                                <input type="text" name="body_temperature" class="form-control" value="<?php echo $row['body_temperature']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Covid Diagnosed</label>
                                <select name="covid_diagnosed" class="form-control" required>
                                    <option value="Yes" <?php echo $row['covid_diagnosed'] == 'Yes' ? 'selected' : ''; ?>>Yes</option>
                                    <option value="No" <?php echo $row['covid_diagnosed'] == 'No' ? 'selected' : ''; ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label>Covid Vaccinated</label>
                                <select name="covid_vaccinated" class="form-control" required>
                                    <option value="Yes" <?php echo $row['covid_vaccinated'] == 'Yes' ? 'selected' : ''; ?>>Yes</option>
                                    <option value="No" <?php echo $row['covid_vaccinated'] == 'No' ? 'selected' : ''; ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label>Nationality</label>
                                <input type="text" name="nationality" class="form-control" value="<?php echo $row['nationality']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label>Gender</label>
                                <select name="gender" class="form-control" required>
                                    <option value="Male" <?php echo $row['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo $row['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="update" class="btn btn-warning mt-3">Update Record</button>
                    </form>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

      <!-- jQuery and custom JavaScript for logout button -->
      <script src="..\public\plugins\jquery\jquery-3.7.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // When the logout button is clicked
            $("#logoutBtn").click(function() {
                window.location.href = "logout.php";  // Redirect to logout.php
            });
        });
    </script>
</body>
</html>
