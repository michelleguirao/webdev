<?php
// Include the database connection file
include('dbconn.php');

// Create a new instance of the Config class to establish the connection
$config = new Config();
$conn = $config->conn;

// Handle record update if AJAX request is made
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $update_data = $_POST['update_data']; // Array of updated data

    foreach ($update_data as $data) {
        $column = $data['column'];
        $new_value = $data['new_value'];

        // Sanitize input values to avoid SQL injection
        $new_value = $conn->real_escape_string($new_value);

        // Create SQL query to update the database record
        $sql = "UPDATE health_declarations SET $column = '$new_value' WHERE id = $id";

        // Execute the update query
        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $conn->error;
            exit;
        }
    }

    echo "Record updated successfully";
    exit; // Send success message to the front-end
}

// Handle record delete if AJAX request is made
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    // Create SQL query to delete the record
    $sql = "DELETE FROM health_declarations WHERE id = $id";

    // Execute the delete query
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
        exit; // Send success message to the front-end
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle adding a new record
if (isset($_POST['add'])) {
    // Get data from the form and sanitize it
    $fname = $conn->real_escape_string($_POST['fname']);
    $lname = $conn->real_escape_string($_POST['lname']);
    $mobile_number = $conn->real_escape_string($_POST['mobile_number']);
    $age = $_POST['age'];
    $body_temperature = $_POST['body_temperature'];
    $covid_diagnosed = $_POST['covid_diagnosed'];
    $covid_vaccinated = $_POST['covid_vaccinated'];
    $nationality = $conn->real_escape_string($_POST['nationality']);
    $gender = $_POST['gender'];

    // Insert the new record into the database
    $sql = "INSERT INTO health_declarations (fname, lname, mobile_number, age, body_temperature, covid_diagnosed, covid_vaccinated, nationality, gender) 
            VALUES ('$fname', '$lname', '$mobile_number', '$age', '$body_temperature', '$covid_diagnosed', '$covid_vaccinated', '$nationality', '$gender')";

    if ($conn->query($sql) === TRUE) {
        echo "New record added successfully";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// Fetch all records for displaying in the table
$sql = "SELECT * FROM health_declarations";
$result = $conn->query($sql);

// Close connection (optional)
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Users Database</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="..\public\plugins\jquery\jquery-3.7.1.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-4">
                    <div class="card-header">
                        <h2 class="display-6 text-center">Health Declarations</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Mobile Number</th>
                                    <th>Age</th>
                                    <th>Body Temperature</th>
                                    <th>Covid Diagnosed</th>
                                    <th>Covid Vaccinated</th>
                                    <th>Nationality</th>
                                    <th>Gender</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                                        echo "<td class='editable' data-column='fname'>" . htmlspecialchars($row["fname"]) . "</td>";
                                        echo "<td class='editable' data-column='lname'>" . htmlspecialchars($row["lname"]) . "</td>";
                                        echo "<td class='editable' data-column='mobile_number'>" . htmlspecialchars($row["mobile_number"]) . "</td>";
                                        echo "<td class='editable' data-column='age'>" . htmlspecialchars($row["age"]) . "</td>";
                                        echo "<td class='editable' data-column='body_temperature'>" . htmlspecialchars($row["body_temperature"]) . "</td>";
                                        echo "<td class='editable' data-column='covid_diagnosed'>" . htmlspecialchars($row["covid_diagnosed"]) . "</td>";
                                        echo "<td class='editable' data-column='covid_vaccinated'>" . htmlspecialchars($row["covid_vaccinated"]) . "</td>";
                                        echo "<td class='editable' data-column='nationality'>" . htmlspecialchars($row["nationality"]) . "</td>";
                                        echo "<td class='editable' data-column='gender'>" . htmlspecialchars($row["gender"]) . "</td>";
                                        echo "<td>
                                                <a href='#' class='btn btn-primary btn-sm edit-btn' data-id='" . $row["id"] . "'>Edit</a>
                                                <a href='#' class='btn btn-success btn-sm save-btn' data-id='" . $row["id"] . "' style='display:none;'>Save</a>
                                                <a href='#' class='btn btn-danger btn-sm delete-btn' data-id='" . $row["id"] . "'>Delete</a>
                                              </td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='11' class='text-center'>No records found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add New Record Form -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>Add New Record</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Last Name</label>
                            <input type="text" name="lname" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Mobile Number</label>
                            <input type="text" name="mobile_number" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Age</label>
                            <input type="number" name="age" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Body Temperature</label>
                            <input type="text" name="body_temperature" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Covid Diagnosed</label>
                            <select name="covid_diagnosed" class="form-control" required>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Covid Vaccinated</label>
                            <select name="covid_vaccinated" class="form-control" required>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Nationality</label>
                            <input type="text" name="nationality" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label>Gender</label>
                            <select name="gender" class="form-control" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" name="add" class="btn btn-success mt-3">Add Record</button>
                </form>
            </div>
        </div>

        <!-- Logout Button -->
        <form method="POST" class="mt-3">
            <button type="submit" name="logout" class="btn btn-danger">Logout</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="..\public\plugins\jquery\jquery-3.7.1.min.js"></script>
    <script>
        $(document).ready(function () {
    // Handle editing
    $('.edit-btn').on('click', function () {
        const row = $(this).closest('tr');
        const id = $(this).data('id');

        // Enable contenteditable on the row's cells
        row.find('.editable').each(function () {
            $(this).attr('contenteditable', 'true');
        });

        // Hide the "Edit" button and show the "Save" button
        $(this).hide();  // Hide "Edit" button
        row.find('.save-btn').show();  // Show "Save" button
    });

    // Handle saving the updated content
    $('.save-btn').on('click', function () {
        const row = $(this).closest('tr');
        const id = $(this).data('id');
        const updateData = [];

        row.find('.editable').each(function () {
            const column = $(this).data('column');
            const newValue = $(this).text();  // Get the new value directly from the cell
            updateData.push({ column: column, new_value: newValue });

            // Disable contenteditable after saving
            $(this).attr('contenteditable', 'false');
        });

        // Hide the "Save" button and show the "Edit" button again
        row.find('.save-btn').hide();
        row.find('.edit-btn').show();

        // Send the update request to the server
        $.ajax({
            url: '',  // Adjust this to the correct URL if needed
            method: 'POST',
            data: {
                update: true,
                id: id,
                update_data: updateData
            },
            success: function (response) {
                alert(response);  // Show the server response
            }
        });
    });

    // Handle deleting
    $('.delete-btn').on('click', function () {
        const id = $(this).data('id');
        if (confirm('Are you sure you want to delete this record?')) {
            $.ajax({
                url: '',
                method: 'POST',
                data: {
                    delete: true,
                    id: id
                },
                success: function (response) {
                    alert(response);
                    location.reload(); // Reload page to reflect changes
                }
            });
        }
    });

    // Handle adding a new record via AJAX
    $('form').on('submit', function (event) {
        event.preventDefault();  // Prevent the default form submission

        // Gather form data
        const formData = $(this).serialize();

        // Send the data to the server
        $.ajax({
            url: '',  // Adjust this to the correct URL if needed
            method: 'POST',
            data: formData + '&add=true', // Add the 'add' flag to trigger the insert in PHP
            success: function (response) {
                alert(response);  // Show success message
                location.reload(); // Refresh the page to show the new record
            },
            error: function () {
                alert('Error adding record');
            }
        });
    });
});
    </script>
</body>
</html>
