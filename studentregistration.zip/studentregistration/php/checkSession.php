<?php
session_start();

$response = array();

if (isset($_SESSION['is_admin'])) {
    $response['isSuccess'] = true;
    $response['username'] = $_SESSION['username'];
    $response['isAdmin'] = $_SESSION['is_admin'];  // Send the is_admin status as a boolean
    
} else {
    $response['isSuccess'] = false;
    $response['msg'] = 'User not logged in or session expired.';
}

echo json_encode($response);
?>
