<?php
include 'dbconn.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['error' => 'You must be logged in to borrow a book.']);
    exit;
}

$username = $_SESSION['username'];

// Get input data   
$data = json_decode(file_get_contents('php://input'), true);
$bookId = $data['id'] ?? null;

if ($bookId) {
    // Check current status of the book
    $sql = "SELECT status FROM book_info WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $bookId);
    $stmt->execute();
    $stmt->bind_result($currentStatus);
    $stmt->fetch();
    $stmt->close();

    // Update status based on current state
    if ($currentStatus === null || $currentStatus === 'NULL') {
        // Set status to 'Pending' if it's NULL
        $newStatus = 'Pending';
    } else if ($currentStatus === 'Pending') {
        // Set status to 'Borrowed' if it's Pending
        $newStatus = 'Borrowed';
    } else {
        // Invalid transition or already borrowed
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action or book already borrowed.']);
        exit;
    }

    // Update the book record
    $updateSql = "UPDATE book_info SET status = ?, users_username = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param('ssi', $newStatus, $username, $bookId);

    if ($updateStmt->execute()) {
        echo json_encode(['success' => true, 'new_status' => $newStatus]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update the book status.']);
    }

    $updateStmt->close();
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid input.']);
}

$conn->close();
?>
