<?php
session_start();
require_once('dbconn.php');

// Check if the user is logged in (has a session)
if (!isset($_SESSION['username'])) {
    header("Location: signUp.html"); // Redirect to signup if not logged in
    exit;
}

function saveHealthDeclaration($username, $fname, $lname, $mobilenumber, $age, $bodytemperature, $covid_diagnosed, $covid_vaccinated, $nationality, $gender) {
    $response = array();

    // Initialize the database connection
    $config = new Config();
    $conn = $config->conn;

    // Check for connection errors
    if ($conn->connect_error) {
        return "Connection failed: " . $conn->connect_error;
    } else {
        // Prepare the SQL query to insert health declaration data
        $query = 'INSERT INTO health_declarations (fname, lname, mobile_number, age, body_temperature, covid_diagnosed, covid_vaccinated, nationality, gender, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('ssisssssss', $fname, $lname, $mobilenumber, $age, $bodytemperature, $covid_diagnosed, $covid_vaccinated, $nationality, $gender, $username);

            // Execute the query
            if ($stmt->execute()) {
                echo "<script>
                        alert('Health Declaration Saved Successfully!');
                        window.location.href = 'http://localhost/studentregistration/login.html';  // Redirect to login page
                      </script>";
                exit; 
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Failed to save health declaration.';
            }

            // Close the statement
            $stmt->close();
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to prepare statement for health declaration.';
        }
    }

    // Close the database connection
    $conn->close();

    // Return the response
    return $response;
}

// Example usage
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_SESSION['username']; // Get the username from the session
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobilenumber = $_POST['mobilenumber'];
    $age = $_POST['age'];
    $bodytemperature = $_POST['bodytemperature'];
    $covid_diagnosed = $_POST['covid_diagnosed'];
    $covid_vaccinated = $_POST['covid_vaccinated'];
    $nationality = $_POST['nationality'];
    $gender = $_POST['gender'];

    // Create an instance and save health data
    $result = saveHealthDeclaration($username, $fname, $lname, $mobilenumber, $age, $bodytemperature, $covid_diagnosed, $covid_vaccinated, $nationality, $gender);

    // Output the result as JSON
    echo json_encode($result);
}
?>
