<?php
include 'dbconn.php';  // Make sure you have your dbconn.php set up correctly

// Get the status filter from the URL parameter (default is 'all')
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Prepare the SQL query based on the status filter
if ($statusFilter == 'all') {
    // Get books that are either Pending or Borrowed
    $sql = "SELECT id, bname, status FROM book_info WHERE status IN ('Pending', 'Borrowed')";
} else {
    // If the filter contains 'Pending,Borrowed', split it and fetch both statuses
    $statusArray = explode(',', $statusFilter);  // Split 'Pending,Borrowed' into an array
    $sql = "SELECT id, bname, status FROM book_info WHERE status IN (?, ?)";
}

// Prepare and execute the SQL statement
$stmt = $conn->prepare($sql);

// If the status is not "all", bind the status parameters
if ($statusFilter != 'all') {
    $stmt->bind_param("ss", $statusArray[0], $statusArray[1]);
}

$stmt->execute();
$result = $stmt->get_result();

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($books);

$stmt->close();
$conn->close();
?>
