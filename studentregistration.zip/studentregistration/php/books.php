<?php
include 'dbconn.php';

// Fetch all books
$sql = "SELECT id, bname, author, date, synopsis, img_directory, status FROM book_info";
$result = $conn->query($sql);

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($books);
$conn->close();
?>
