// Global variable to store the current filter
let currentFilter = "all"; // Default filter is 'all'

// Function to fetch books based on the filter
async function fetchBooks() {
  try {
    const response = await fetch(`php/bag.php?status=${currentFilter}`); // Send filter as query param
    const books = await response.json(); // Parsing the JSON data

    const tableBody = document.querySelector("#bookTable tbody");
    tableBody.innerHTML = ""; // Clear any existing rows

    // If no books are returned
    if (books.length === 0) {
      const row = document.createElement("tr");
      row.innerHTML = "<td colspan='2'>No books found for this filter</td>";
      tableBody.appendChild(row);
    }

    books.forEach((book) => {
      const row = document.createElement("tr");

      // Insert Book Name and Status columns into the row
      row.innerHTML = `
                <td>${book.bname}</td>
                <td class="status-cell">${book.status}</td>
            `;
      tableBody.appendChild(row); // Append the row to the table
    });
  } catch (error) {
    console.error("Error fetching books:", error); // Log any error that occurs
  }
}

// Event listeners for filter buttons
document.getElementById("allBooks").addEventListener("click", () => {
  currentFilter = "Pending, Borrowed"; // Set filter to 'all'
  fetchBooks(); // Fetch books based on the new filter
});

document.getElementById("pendingBooks").addEventListener("click", () => {
  currentFilter = "Pending"; // Set filter to 'Pending'
  fetchBooks(); // Fetch books based on the new filter
});

document.getElementById("borrowedBooks").addEventListener("click", () => {
  currentFilter = "Borrowed"; // Set filter to 'Borrowed'
  fetchBooks(); // Fetch books based on the new filter
});

// Initialize the table with all books on page load
fetchBooks();
