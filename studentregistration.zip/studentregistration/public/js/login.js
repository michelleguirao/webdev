var formatBlock = function () {
  return {
    message: '<img src="loadingawda.gif" alt="Loading..." />', // Customize the loading message or image
    css: {
      border: "none",
      padding: "15px",
      backgroundColor: "#fff",
      "-webkit-border-radius": "10px",
      "-moz-border-radius": "10px",
      opacity: 0.8,
      color: "#000",
    },
  };
};

var login = (function () {
  var checkSession = function () {
    $.get(
      "php/checkSession.php",
      function (data) {
        if (data.isSuccess) {
          if (data.isAdmin) {
            // This should now be a boolean value
            window.location.href =
              "http://localhost/studentregistration/admindashboard.html";
          } else {
            window.location.href =
              "http://localhost/studentregistration/dashboard.html";
          }
        }
      },
      "json"
    );
  };

  var onLogin = function () {
    $("#frmLogin").submit(function (e) {
      e.preventDefault();
      $("#login").block(formatBlock());

      var loginObj = $("#frmLogin").serializeArray();
      $.post(
        "php/loginStudent.php",
        loginObj,
        function (data) {
          console.log(data);
          if (!data.isSuccess) {
            var msg = data.msg;
            var alert =
              "<div class='alert alert-danger fade in'>" +
              "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>" +
              "Message!<br/>" +
              msg +
              "</div>";
            $("#admin-msg").html(alert);
          } else {
            // Only check session after a successful login
            checkSession();
          }
          $("#login").unblock();
        },
        "json"
      );
    });
  };

  // Public API
  return {
    init: function () {
      // Don't check session here - only call checkSession on successful login
      onLogin();
    },
  };
})();
// Initialize login script
$(document).ready(function () {
  login.init();
});
