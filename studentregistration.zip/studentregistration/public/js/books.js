// Fetch and display books
async function fetchBooks() {
  const response = await fetch("php/books.php");
  const books = await response.json();
  const tableBody = document.querySelector("#bookTable tbody");
  tableBody.innerHTML = "";

  books.forEach((book) => {
    const row = document.createElement("tr");
    row.setAttribute("data-book-id", book.id); // Add a data attribute for tracking

    row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.bname}</td>
            <td>${book.author}</td>
            <td>${book.date}</td>
            <td>${book.synopsis}</td>
            <td>${book.img_directory}</td>
            <td class="status-cell">
                ${
                  book.status === "Pending"
                    ? "Pending"
                    : `<button onclick="borrowBook(${book.id}, this)">Borrow</button>`
                }
            </td>
        `;
    tableBody.appendChild(row);
  });
}

// Borrow book
async function borrowBook(bookId, buttonElement) {
  const response = await fetch("php/borrow.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id: bookId }),
  });

  if (response.ok) {
    // Update button to show "Pending" immediately
    const statusCell = buttonElement.parentElement;
    statusCell.innerHTML = "Pending";
    alert("Thank you for borrowing the book. Please wait for");
  } else {
    alert("Error borrowing the book.");
  }
}

// Initialize the table on page load
fetchBooks();
