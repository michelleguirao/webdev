$(document).ready(function () {
  // Fetch user data from the server
  $.ajax({
    url: "php/dashboard.php",
    type: "GET",
    dataType: "json",
    success: function (response) {
      if (response.isSuccess) {
        // Update welcome message
        $("#welcomeMessage").text("Welcome, " + response.username + "!");
        if (response.userData) {
          const userData = response.userData;
          $("#fname").text(userData.fname);
          $("#lname").text(userData.lname);
          $("#mobile_number").text(userData.mobile_number);
          $("#age").text(userData.age);
          $("#year_section").text(userData.year_section);
          $("#gender").text(userData.gender);
          $("#user_info").show();
          $("#noDataMessage").hide();
        } else {
          $("#user_info").hide();
          $("#noDataMessage").show();
        }
      } else {
        // Handle session expiration or errors
        alert(response.msg || "Session expired. Please log in again.");
        window.location.href = "php/loginStudent.php";
      }
    },
    error: function (xhr, status, error) {
      alert("Failed to fetch data. Please try again.");
      console.error("Error: ", error);
    },
  });

  // Log out handler
  $("#logoutBtn").click(function () {
    window.location.href = "php/logout.php";
  });
});
