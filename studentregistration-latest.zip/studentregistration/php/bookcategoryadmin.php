<?php

include('dbconn.php'); // Include the database connection

$config = new Config();
$conn = $config->conn;

// Handle fetch request to get all categories
if (isset($_POST['fetch'])) {
    $sql = "SELECT * FROM book_category"; // Use book_category as the table name
    $result = $conn->query($sql);
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows); // Return the fetched data as JSON
    exit;
}

// Handle record update if AJAX request is made
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $update_data = $_POST['update_data']; // Array of updated data

    foreach ($update_data as $data) {
        $column = $data['column'];
        $new_value = $data['new_value'];

        // Sanitize input values to avoid SQL injection
        $new_value = $conn->real_escape_string($new_value);

        // Create SQL query to update the database record
        $sql = "UPDATE book_category SET $column = '$new_value' WHERE book_id = $id";

        // Execute the update query
        if ($conn->query($sql) !== TRUE) {
            echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
            exit;
        }
    }

    echo json_encode(['status' => 'success', 'message' => 'Record updated successfully']);
    exit;
}

// Handle record delete if AJAX request is made
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    // Create SQL query to delete the record
    $sql = "DELETE FROM book_category WHERE book_id = $id";

    // Execute the delete query
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Record deleted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
    exit;
}

// Handle adding a new record
if (isset($_POST['add'])) {
    // Get data from the form and sanitize it
    $book_id = $conn->real_escape_string($_POST['book_id']);
    $is_fiction = isset($_POST['is_fiction']) ? 1 : 0;
    $is_non_fiction = isset($_POST['is_non_fiction']) ? 1 : 0;
    $is_science = isset($_POST['is_science']) ? 1 : 0;
    $is_history = isset($_POST['is_history']) ? 1 : 0;
    $is_philosophy = isset($_POST['is_philosophy']) ? 1 : 0;
    $is_technology = isset($_POST['is_technology']) ? 1 : 0;
    $is_art = isset($_POST['is_art']) ? 1 : 0;
    $is_biography = isset($_POST['is_biography']) ? 1 : 0;
    $is_mystery = isset($_POST['is_mystery']) ? 1 : 0;
    $is_fantasy = isset($_POST['is_fantasy']) ? 1 : 0;

    // Ensure all required fields are provided
    if (empty($book_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Book ID is required']);
        exit;
    }

    // Insert the new record into the book_category table
    $sql = "INSERT INTO book_category (book_id, is_fiction, is_non_fiction, is_science, is_history, is_philosophy, is_technology, is_art, is_biography, is_mystery, is_fantasy)
            VALUES ('$book_id', '$is_fiction', '$is_non_fiction', '$is_science', '$is_history', '$is_philosophy', '$is_technology', '$is_art', '$is_biography', '$is_mystery', '$is_fantasy')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'New category added successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
    exit;
}

// Close connection (optional)
$conn->close();

?>
