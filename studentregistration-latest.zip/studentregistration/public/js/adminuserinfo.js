function fetchData() {
    $.post('php/userinfoadmin.php', { fetch: true }, function (data) {
        const rows = JSON.parse(data);
        let content = '';
        rows.forEach(row => {
            content += `<tr>
                <td>${row.id}</td>
                <td class="editable" data-column="fname">${row.fname}</td>
                <td class="editable" data-column="lname">${row.lname}</td>
                <td class="editable" data-column="mobile_number">${row.mobile_number}</td>
                <td class="editable" data-column="age">${row.age}</td>
                <td class="editable" data-column="year_section">${row.year_section}</td>
                <td class="editable" data-column="course">${row.course}</td>
                <td class="editable" data-column="gender">${row.gender}</td>
                <td>
                    <button class="btn btn-primary btn-sm edit-btn" data-id="${row.id}">Edit</button>
                    <button class="btn btn-success btn-sm save-btn" data-id="${row.id}" style="display:none;">Save</button>
                    <button class="btn btn-danger btn-sm delete-btn" data-id="${row.id}">Delete</button>
                </td>
            </tr>`;
        });
        $('#dataTable').html(content);
    });
}

fetchData();

$('#addForm').on('submit', function (event) {
    event.preventDefault();
    const formData = $(this).serialize() + '&add=true';
    $.post('php/userinfoadmin.php', formData, function (response) {
        alert(response);
        fetchData();
        $('#addForm')[0].reset();
    });
});

$(document).on('click', '.edit-btn', function () {
    const row = $(this).closest('tr');
    row.find('.editable').attr('contenteditable', 'true');
    $(this).hide();
    row.find('.save-btn').show();
});

$(document).on('click', '.save-btn', function () {
    const row = $(this).closest('tr');
    const id = $(this).data('id');
    const updatedData = [];

    row.find('.editable').each(function () {
        const column = $(this).data('column');
        const newValue = $(this).text();
        updatedData.push({ column, new_value: newValue });
    });

    $.post('php/userinfoadmin.php', { update: true, id, update_data: updatedData }, function (response) {
        alert(response.message);
        fetchData();
    });
    row.find('.editable').attr('contenteditable', 'false');
    $(this).hide();
    row.find('.edit-btn').show();
});

$(document).on('click', '.delete-btn', function () {
    const id = $(this).data('id');
    if (confirm('Are you sure you want to delete this record?')) {
        $.post('php/userinfoadmin.php', { delete: true, id }, function (response) {
            alert(response.message);
            fetchData();
        });
    }
});