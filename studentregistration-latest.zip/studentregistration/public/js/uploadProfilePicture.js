document.getElementById('profileUpload').addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        const formData = new FormData();
        formData.append('profile_picture', file);

        fetch('php/uploadProfilePicture.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json()) // Expecting a JSON response from PHP
        .then(result => {
            if (result.filename) {
                alert('Profile picture uploaded successfully!');

                // Update the profile picture by setting the new image source
                const timestamp = new Date().getTime(); // Add timestamp to avoid caching issues
                const imagePath = `public/img/${result.filename}`;
                document.getElementById('profilepicture').src = `${imagePath}?t=${timestamp}`; // Dynamically update the profile picture

            } else {
                alert(result.error); // Display any error message from PHP
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('There was an error uploading your profile picture.');
        });
    }
});
