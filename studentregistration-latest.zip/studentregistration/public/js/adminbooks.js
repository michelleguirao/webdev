// Define the fetchBookInfo function outside the $(document).ready() block
function fetchBookInfo() {
  $.post("php/fetchbooks.php", { fetch: true }, function (data) {
    const books = JSON.parse(data);
    const tableBody = $("#bookDataTable");
    tableBody.empty(); // Clear existing table data

    books.forEach((book) => {
      // Check if image data exists
      const image = book.img_directory
        ? `<img src="data:image/jpg;base64,${book.img_directory}" alt="${book.bname}" height="50" />`
        : "No Image";

      // Create table row for each book
      const row = ` 
          <tr>
            <td>${book.id}</td>
            <td class="editable" data-column="bname">${book.bname}</td>
            <td class="editable" data-column="author">${book.author}</td>
            <td class="editable" data-column="date">${book.date}</td>
            <td class="editable" data-column="synopsis">${book.synopsis}</td>
            <td>${book.status}</td>
            <td>${book.users_username}</td>
            <td>${image}</td>
            <td>
              <button class="btn btn-primary btn-sm edit-btn">Edit</button>
              <button class="btn btn-success btn-sm save-btn" data-id="${book.id}" style="display:none;">Save</button>
              <button class="btn btn-danger btn-sm delete-btn" data-id="${book.id}">Delete</button>
            </td>
          </tr>`;

      tableBody.append(row); // Append new row to the table
    });
  }).fail(function () {
    console.error("Error fetching book data.");
  });
}

$(document).ready(function () {
  // Fetch and populate book info when the page is loaded
  fetchBookInfo();

  // Handle Add Book form submission
  $("#addBookForm").on("submit", function (event) {
    event.preventDefault(); // Prevent the default form submission
    const formData = new FormData(this);
    formData.append("add", true); // Add 'add' flag to the form data

    // Send the form data via AJAX to add a new book
    $.ajax({
      url: "php/bookinfoadmin.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        alert(response); // Show success message
        fetchBookInfo(); // Reload the table to show the new book
        $("#addBookForm")[0].reset(); // Reset the form
      },
      error: function (error) {
        console.error("Error adding book:", error); // Handle errors
      },
    });
  });
});

// Edit, Save, Delete functionality
$(document).on("click", ".edit-btn", function () {
  const row = $(this).closest("tr");
  row.find(".editable").attr("contenteditable", "true");
  $(this).hide();
  row.find(".save-btn").show();
});

$(document).on("click", ".save-btn", function () {
  const row = $(this).closest("tr");
  const id = $(this).data("id");
  const updatedData = [];

  row.find(".editable").each(function () {
    const column = $(this).data("column");
    const newValue = $(this).text();
    updatedData.push({ column, new_value: newValue });
  });

  $.post(
    "php/bookinfoadmin.php",
    { update: true, id, update_data: updatedData },
    function (response) {
      alert(response.message);
      fetchBookInfo(); // Refresh book list after update
    }
  );

  row.find(".editable").attr("contenteditable", "false");
  $(this).hide();
  row.find(".edit-btn").show();
});

$(document).on("click", ".delete-btn", function () {
  const id = $(this).data("id");
  if (confirm("Are you sure you want to delete this record?")) {
    $.post("php/bookinfoadmin.php", { delete: true, id }, function (response) {
      alert(response.message);
      fetchBookInfo(); // Refresh book list after deletion
    });
  }
});

function fetchCategories() {
  $.post("php/bookcategoryadmin.php", { fetch: true }, function (data) {
    const rows = JSON.parse(data);
    let content = "";
    rows.forEach((row) => {
      content += `<tr>
                <td>${row.book_id}</td>
                <td><input type="checkbox" ${
                  row.is_fiction ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_non_fiction ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_science ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_history ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_philosophy ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_technology ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_art ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_biography ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_mystery ? "checked" : ""
                } disabled></td>
                <td><input type="checkbox" ${
                  row.is_fantasy ? "checked" : ""
                } disabled></td>
                <td>
                    <button class="btn btn-primary btn-sm edit-btn" data-id="${
                      row.book_id
                    }">Edit</button>
                    <button class="btn btn-success btn-sm save-btn" data-id="${
                      row.book_id
                    }" style="display:none;">Save</button>
                    <button class="btn btn-danger btn-sm delete-btn" data-id="${
                      row.book_id
                    }">Delete</button>
                </td>
            </tr>`;
    });
    $("#categoryDataTable").html(content);
  });
}

fetchCategories();
