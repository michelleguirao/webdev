var formatBlock = function (blockmsg) {
  return {
    message: blockmsg,
    css: {
      border: "none",
      padding: "15px",
      backgroundColor: "#000",
      "-webkit-border-radius": "10px",
      "-moz-border-radius": "10px",
      opacity: 0.5,
      color: "#fff",
      width: "200px",
    },
  };
};

var checkSession = function () {
  $.get("checksession.php", function (data) {
    var sessiondata = $.parseJSON(data);
    if (!sessiondata.isSuccess) {
      $(location).attr("href", "login.html");
    } else {
      loadFirst();
    }
  });
};

var loadFirst = function () {
  setTimeout(function () {
    $("#core").removeClass("hidden");
    // $('#loader').addClass('hidden');
  }, 1000);
};

if (typeof $.blockUI === "function" && typeof $.unblockUI === "function") {
  console.log("BlockUI functions are available!");
} else {
  console.log(
    "BlockUI functions are not available. Please ensure the plugin is loaded correctly."
  );
}

$("#user_info").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * User Information block ui
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("userinformation.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {});
    });
  });
});

$("#books").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * books Block UI
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("books.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {
        $("#main-content").unblock();
      });
    });
  });
});

$("#bag").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * Bag block ui
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("bag.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {
        $("#main-content").unblock();
      });
    });
  });
});

// $("#index").click(function (event) {
//   var blockmsg =
//     'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';

//   $.blockUI(formatBlock(blockmsg));
//   $("#main-content").fadeOut("400", function () {
//     $.get("dashboard.html", function (data) {
//       $("#main-content").html(data);
//       $("#viewstitle").html("Dashboard");
//       $("#main-content").fadeIn("400");
//       $.unblockUI();
//     });
//   });
// });

var Index = (function () {
  "use strict";

  return {
    init: function () {
      checkSession();
    },
  };
})();
