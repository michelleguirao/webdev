<?php
session_start();  // Start the session
session_destroy(); // Destroy the session

// Redirect to the login page
header("Location: http://localhost/studentregistration/login.html");
exit;
?>